library("MASS") # for Boston Housing data
parcoord(Boston)