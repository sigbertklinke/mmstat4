data(Boston, package="MASS")
pairs(~rm+lstat+medv, data=Boston, cex=0.5)