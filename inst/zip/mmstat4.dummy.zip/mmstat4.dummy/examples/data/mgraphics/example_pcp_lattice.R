library("MASS") # for Boston Housing data
library("lattice")
parallelplot(Boston, horizontal.axis=F)