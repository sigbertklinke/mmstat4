n <- 5
sample(1:n, n)
sample(1:n, n, replace=T)
library("sampling")
srswr(n,n)