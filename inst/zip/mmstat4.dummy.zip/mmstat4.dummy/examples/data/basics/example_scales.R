x <- 1:5
x
f <- factor(x)
f
g <- factor(x, levels=1:6)
g
o <- ordered(x)
o
