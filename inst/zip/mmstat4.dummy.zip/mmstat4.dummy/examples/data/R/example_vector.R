vn <- c(1, 2, 3, 4, 5)
vn
vn <- 1:10
vn
vt  <- c("a", "b", "c", "d")
vt
vb  <- c(TRUE, FALSE, NA)
vb
length(vn)
length(vb)
vt[1]
vt[-1]
vt[c(1,2,3)]
vt[2:3]
vn <- c("eins"=1, "zwei"=2, "drei"=3, "vier"=4, "fuenf"=5)
vn
vn["drei"]
names(vn)
