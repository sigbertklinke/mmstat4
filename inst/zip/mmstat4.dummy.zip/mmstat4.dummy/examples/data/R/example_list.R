l <- list(a=1, b=TRUE, c="text", NA)
l
length(l)
l$a
l[[1]]
l[['a']]
l[1]
names(l)
