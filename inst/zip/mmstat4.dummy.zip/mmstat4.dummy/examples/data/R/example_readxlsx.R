library("xlsx")
x <- read.xlsx("kriegsschiffe.xlsx", 1)
dim(x)