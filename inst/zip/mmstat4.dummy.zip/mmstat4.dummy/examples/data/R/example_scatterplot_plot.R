library("MASS")  # for Boston Housing data
# standard graphics
plot(Boston$lstat, Boston$medv)
