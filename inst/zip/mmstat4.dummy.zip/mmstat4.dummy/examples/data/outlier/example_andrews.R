library("MASS")  # for Boston Housing data
library("andrews")
andrews(Boston)
