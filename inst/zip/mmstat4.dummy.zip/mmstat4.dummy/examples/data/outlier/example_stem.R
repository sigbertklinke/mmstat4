library("MASS") # for Boston Housing data
stem(Boston$medv)