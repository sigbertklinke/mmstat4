n <- 10000
x <- rnorm(n)
boxplot(x, horizontal=T)
rug(x)