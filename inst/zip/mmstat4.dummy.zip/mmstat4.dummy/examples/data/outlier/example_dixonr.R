library("outliers")
x <- c(rnorm(29),4)
dixon.test(x)