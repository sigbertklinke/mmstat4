library("MASS") # for Boston Housing data
stripchart(Boston$medv, method="j")
