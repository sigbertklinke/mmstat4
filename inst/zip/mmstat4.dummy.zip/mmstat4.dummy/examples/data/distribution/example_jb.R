library("DescTools")
data(Boston, package="MASS")
JarqueBeraTest(Boston$medv)	
