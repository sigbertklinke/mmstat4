library("MASS") # for Boston Housing data
# histogram + observations
hist(Boston$medv)
rug(Boston$medv)
