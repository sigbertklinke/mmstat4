library("MASS") # for Boston Housing data
boxplot(medv~rad, data=Boston)
