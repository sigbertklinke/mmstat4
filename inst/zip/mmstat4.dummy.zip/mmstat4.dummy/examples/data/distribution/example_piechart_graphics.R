library("MASS") # for Boston Housing data
tab <- table(Boston$rad)
pie(tab)
