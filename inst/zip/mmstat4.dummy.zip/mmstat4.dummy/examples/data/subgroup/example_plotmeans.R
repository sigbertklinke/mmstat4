library("MASS")
library("gplots")
plotmeans(medv~rad, data=Boston, connect=F)