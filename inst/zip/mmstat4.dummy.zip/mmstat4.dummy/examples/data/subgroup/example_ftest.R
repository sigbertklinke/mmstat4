data(Boston, package="MASS")
var.test(medv~chas, data=Boston)