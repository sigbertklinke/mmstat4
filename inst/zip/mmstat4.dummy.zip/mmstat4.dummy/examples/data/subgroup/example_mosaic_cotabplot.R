library("vcd")
cotabplot(Titanic)