library("vcd")
mosaic(Titanic)