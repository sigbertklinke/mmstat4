plot(Titanic)
mosaicplot(Titanic)
#
library("vcd")
mosaic(Titanic)
cotabplot(Titanic)