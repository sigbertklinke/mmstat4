data(Boston, package="MASS")
t.test(Boston$medv, mu=10)
