library("VIM")
mm <- aggr(sleep) # plot(mm)
print(mm)
summary(mm)
