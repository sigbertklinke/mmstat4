library("MissingDataGUI") # for brfss data
MissingDataGUI(brfss)