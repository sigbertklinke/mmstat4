# devtools::install_github("sigbertklinke/smvgraph")
library("smvgraph")
splot() # or splot(iris)