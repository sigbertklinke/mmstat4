library("MASS") # for Boston Housing data

cov(Boston)