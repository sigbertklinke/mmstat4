library("spdep")
data("boston")
plot(boston.c$LON, boston.c$LAT, main="Boston school districts")
