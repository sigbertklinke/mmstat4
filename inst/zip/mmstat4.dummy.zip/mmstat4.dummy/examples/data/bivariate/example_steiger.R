library("MASS")   # for Boston Housing data
cor.test(Boston$lstat, Boston$medv)